package com.keshav.TempProject;

public class User {
	
	private String userid;
	private String username;
	private String email;
	private String phone;
	private String compid;
	
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getName() {
		return username;
	}
	public void setName(String name) {
		this.username = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCompany() {
		return phone;
	}
	public void setCompany(String company) {
		this.compid = company;
	}
	@Override
	public String toString() {
		return "userid=" + userid + ", username=" + username + ", email=" + email + ", phone=" + phone
				+ ", company=" + compid + "";
	}
}
