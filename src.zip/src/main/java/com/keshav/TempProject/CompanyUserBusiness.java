package com.keshav.TempProject;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Service
@RequestMapping("/s")
public class CompanyUserBusiness {
	
	@Autowired
	public CompanyUserRepo compUserObj;
	
	@GetMapping("/user")
	public List<String> retrieveAllUser() {
		return Arrays.asList(compUserObj.findAllUser().toString());
	}
	
	@GetMapping("/company/{id}")
	public void deleteComp(@PathVariable String id) {
		compUserObj.deleteCompById(id);
	}
	
	

}
