package com.keshav.TempProject;

public class Company {
	
	private String compid;
	private String name;
	private String city;
	
	public String getCompid() {
		return compid;
	}
	public void setCompid(String compid) {
		this.compid = compid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "CompanyDao [compid=" + compid + ", name=" + name + ", city=" + city + "]";
	}
	
	

}
