package com.keshav.TempProject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;



@Repository
public class CompanyUserRepo {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	class UserRowMapper implements RowMapper<User> {
		@Override
		public User mapRow(ResultSet rs, int rowNum) throws SQLException {
			User user = new User();
			user.setUserid(rs.getString("userid"));
			user.setName(rs.getString("username"));
			user.setEmail(rs.getString("email"));
			user.setPhone(rs.getString("phone"));
			user.setCompany(rs.getString("compid"));
			return user;
		}

	}

	public List<User> findAllUser() {
		return jdbcTemplate.query("select * from user", new UserRowMapper());
	}
		

	public int deleteCompById(String id) {
		return jdbcTemplate.update("delete from company where compid=?", new Object[] { id });
	}

}
