insert into company (compid, name, city) values ("11","Comp A", "City A");
insert into company (compid, name, city) values ("12","Comp B", "City B");
insert into company (compid, name, city) values ("13","Comp C", "City C");

insert into user (userid, username, email, phone, compid) values ("20","user20", "user20@mail.com","919920","11");
insert into user (userid, username, email, phone, compid) values ("21","user21", "user21@mail.com","919920","11");
insert into user (userid, username, email, phone, compid) values ("22","user22", "user22@mail.com","919920","13");