create table company (compid varchar(25) primary key, name varchar(25), city varchar(25));
create table user (userid varchar(25) primary key, username varchar(25), email varchar(25), phone varchar(15), compid varchar (25));

