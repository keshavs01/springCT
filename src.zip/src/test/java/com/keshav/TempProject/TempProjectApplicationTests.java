package com.keshav.TempProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TempProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
